# PANDUAN PASANG v4 — Website di Vercel + Foto Pratinjau WhatsApp + Nama Baru

Website: **https://liputan-kabar-kami-inewscom.vercel.app**
Repo GitHub: **Haris12342/LIPUTAN-KABARI-KAMI.INEWS**
Semua langkah bisa dikerjakan dari HP Android lewat browser.

---

## KENAPA FOTO BELUM TAMPIL DI WHATSAPP (akar masalah, sudah ditemukan)

1. **Website Anda sekarang di-host di VERCEL, bukan Cloudflare lagi.** File `worker.js` yang tugasnya menyuntikkan foto ke pratinjau WhatsApp **hanya berjalan di Cloudflare** — di Vercel dia tidak pernah dijalankan. Akibatnya semua share hanya menampilkan logo lama, bukan foto artikel. **Ini penyebab utamanya.**
2. **URL foto berita "Santunan Anak Yatim…" di versi yang Anda unggah ke GitHub mengandung karakter tak terlihat (U+2060)** — ikut ter-copy saat menempel URL. Karena itu URL-nya jadi 404/rusak: foto itu tidak akan pernah tampil di mana pun. (Sudah diperbaiki di file paket ini.)

## YANG DIPERBAIKI DI PAKET INI (v4)

| Yang berubah | Penjelasan |
|---|---|
| **`api/share.js` (file BARU)** | "Worker" pengganti untuk Vercel (Edge Function). Membaca `BERITA_DATA` dari `index.html` terbaru, mencocokkan artikel dari link, lalu menyuntikkan og:title, og:description, **og:image (foto)**, Twitter Card, canonical untuk bot WhatsApp/FB/Telegram/X. Semua foto dialirkan proxy kompresi wsrv.nl → JPEG 1200×630 (94–410 KB, di bawah batas WA ±600 KB) |
| **`vercel.json` (file BARU)** | Mengarahkan rute `/`, `/b/<slug>`, `/berita/<slug>` ke `api/share.js` — slug berita otomatis diteruskan ke fungsi (`?berita=:slug*`), jadi artikel tetap dikenali apa pun bentuk URL. File gambar/favicon tidak disentuh |
| **Nama website** | Diubah dari "LIPUTAN INEWS HRS.GRUP" menjadi **"LIPUTAN KABARI KAMI.INEWS"** di semua tempat: judul tab, pratinjau medsos, header/footer, halaman redaksi, boot screen |
| **Logo baru** | `logo-kabari-kami.png` (1200×630, navy-merah) dipakai di header + pratinjau medsos; `favicon.png` baru 512×512 |
| **Pembersih URL foto** | Karakter tak terlihat (U+2060, zero-width, BOM, dsb.) yang ikut ter-copy dari WhatsApp/chat **dibersihkan otomatis** di 3 tempat (aplikasi, api/share.js, worker.js). URL foto "sedikit kotor" tetap berfungsi |
| **Format link share** | Tombol share kini menghasilkan `https://…vercel.app/b/<slug>?v=3#<slug>` — jalur khusus yang pasti dibaca fungsi Vercel. `?v=3` memaksa WhatsApp mengambil pratinjau TERBARU |
| **URL foto berita #1** | Diarahkan ke repo baru Anda (tanpa karakter tak terlihat) — teruji 200 OK, hasil kompresi 200 KB |

Hasil pengujian: **90 tes worker (Cloudflare legacy) + 42 tes fungsi Vercel + 11 tes simulasi berita baru + 8 tes browser — SEMUA LOLOS.** Foto repo baru teruji end-to-end: HTTP 200, JPEG 1200×630, 200 KB.

---

## FILE YANG DIUNGGAH KE GITHUB (repo Haris12342/LIPUTAN-KABARI-KAMI.INEWS)

Unggah **5 file ini** ke root repo (isinya ganti/persiapan dari paket `liputan-kabari-kami-vercel`):

| File | Aksi |
|---|---|
| `index.html` | **Replace** (ganti isi file lama) |
| `vercel.json` | **Add** (file baru) |
| `api/share.js` | **Add** (file baru — lihat cara di bawah) |
| `logo-kabari-kami.png` | **Add** (logo baru) |
| `favicon.png` | **Replace** |

> `worker.js`, `wrangler.toml`, `.assetsignore` lama TIDAK dipakai di Vercel — biarkan saja (tidak mengganggu) atau hapus. Versi terbarunya ada di folder `cloudflare-opsional/` bila suatu saat kembali ke Cloudflare.

### Cara unggah dari HP (GitHub web)

1. Buka **github.com** → masuk repo → **Add file → Upload files** → pilih `index.html`, `vercel.json`, `logo-kabari-kami.png`, `favicon.png` dari penyimpanan HP → **Commit changes**.
2. Untuk `api/share.js`: di halaman repo, **Add file → Create new file** → pada kotak nama file ketik: `api/share.js` (GitHub otomatis membuat folder `api`) → salin-tempel seluruh isi file `api/share.js` dari paket ini → **Commit changes**.
   - Cara menyalin isi file dari HP: buka file `api/share.js` dengan aplikasi pengelola file/teks → pilih semua → salin → tempel di GitHub.
3. Tunggu **1–3 menit** — Vercel otomatis deploy ulang begitu repo berubah.
4. Selesai. Tidak ada pengaturan Vercel yang perlu diubah.

---

## SETELAH TERPASANG — CARA MENGECEK (±2 menit)

1. Buka `https://liputan-kabar-kami-inewscom.vercel.app` → pastikan nama di header sudah **LIPUTAN KABARI KAMI.INEWS**.
2. Uji satu link artikel seperti yang dilihat bot WhatsApp:
   `https://liputan-kabar-kami-inewscom.vercel.app/b/santunan-anak-yatim-dan-janda-warnai-peringatan-hut-ke-43-desa?v=3`
   Buka di browser HP → klik kanan → **View page source** (atau tambahkan `view-source:` di depan alamat) → cari `og:image`. Harus berisi `wsrv.nl/?url=…` — itulah foto artikel terkompresi.
3. Uji share dari HP: buka berita → tombol **WhatsApp** → kirim ke diri sendiri. Pratinjau muncul dengan foto.
   - Bila pratinjau pertama masih kosong: tunggu ±1 menit, kirim lagi (bot WA kadang keburu timeout pada pengambilan pertama; percobaan kedua memakai cache yang sudah terisi).
   - Link lama yang pernah dibagikan sebelum perbaikan tidak akan berubah (cache medsos) — selalu share **lewat tombol share di website**.

## BERITA BARU = OTOMATIS 100%

Begitu Anda menambah berita di `window.BERITA_DATA` (index.html, lewat GitHub web) + mengunggah fotonya ke repo:

- Slug, judul, deskripsi, dan **foto pratinjau terkompresi dibuatkan otomatis** oleh `api/share.js` — tidak perlu edit apa pun, tidak perlu set ulang.
- Berita tanpa foto tetap punya pratinjau (otomatis logo situs).
- Syaratnya satu: kolom `foto` berisi URL gambar yang valid (hasil **Upload files** ke repo, klik file foto → **Download/Copy URL** → tempel ke kolom `foto`). Karakter tak terlihat yang ikut ter-copy kini otomatis dibersihkan.

## KALAU SUATU SAAT PRATINJAU LAMA MUNCUL LAGI

Naikkan angka cache-buster `?v=3` menjadi `?v=4` (dua tempat di `index.html` — cari `v=3`), unggah ulang. Link baru = WhatsApp/FB wajib scrape ulang.

## BILA FOTO STILL TIDAK MUNCUL (ceklis singkat)

1. Apakah 5 file sudah terunggah semua (termasuk `api/share.js` dan `vercel.json`)? Bagian file yang hilang = injeksi tidak jalan.
2. Apakah deploy Vercel selesai (tab Deployments di dashboard Vercel: status Ready)?
3. Buka link `view-source:` di atas — ada `og:image` `wsrv.nl`? Kalau ada tapi WA masih kosong → itu cache WA untuk link lama; share ulang pakai tombol share (link `?v=3` baru).
4. Kalau `og:image` tidak ada → screenshot tampilan "View page source" + daftar file di repo, kirim ke saya untuk dicek.
